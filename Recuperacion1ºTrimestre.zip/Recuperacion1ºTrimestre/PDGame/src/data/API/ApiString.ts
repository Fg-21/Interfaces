export default class ApiString{
    public static getAPIBase(): string{
        return "https://ui20251201140330-ahdqhwe3c6cxcrfk.italynorth-01.azurewebsites.net/API/"
    }
}