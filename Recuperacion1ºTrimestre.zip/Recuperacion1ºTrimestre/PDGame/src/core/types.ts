const TYPES = {
    IRepoPersonas: Symbol.for("IRepoPersonas"),
    IRepoDepartamentos: Symbol.for("IRepoDepartamentos"),
    IPersonaDepartamentoUseCase: Symbol.for("IPersonaDepartamentoUseCase")
};

export { TYPES };