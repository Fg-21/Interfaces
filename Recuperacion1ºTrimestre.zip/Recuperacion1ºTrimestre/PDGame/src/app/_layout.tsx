import { HeaderShownContext } from "@react-navigation/elements";
import { Stack } from "expo-router";
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { NavigationContainer } from "@react-navigation/native";

export default function RootLayout() {
  return <Stack/>
}
