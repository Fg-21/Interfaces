/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string | object = string> {
      hrefInputParams: { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/mappers/PersonaTrimmed&ListaDepartamentosDtoToPersonaTrimmed&ListaDepartamentosDto&ColorMapper`; params?: Router.UnknownInputParams; } | { pathname: `/models/PersonaTrimmed&ListaDepartamentosDto&Color`; params?: Router.UnknownInputParams; } | { pathname: `/vms/PDGameVM`; params?: Router.UnknownInputParams; };
      hrefOutputParams: { pathname: Router.RelativePathString, params?: Router.UnknownOutputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownOutputParams } | { pathname: `/`; params?: Router.UnknownOutputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownOutputParams; } | { pathname: `/mappers/PersonaTrimmed&ListaDepartamentosDtoToPersonaTrimmed&ListaDepartamentosDto&ColorMapper`; params?: Router.UnknownOutputParams; } | { pathname: `/models/PersonaTrimmed&ListaDepartamentosDto&Color`; params?: Router.UnknownOutputParams; } | { pathname: `/vms/PDGameVM`; params?: Router.UnknownOutputParams; };
      href: Router.RelativePathString | Router.ExternalPathString | `/${`?${string}` | `#${string}` | ''}` | `/_sitemap${`?${string}` | `#${string}` | ''}` | `/mappers/PersonaTrimmed&ListaDepartamentosDtoToPersonaTrimmed&ListaDepartamentosDto&ColorMapper${`?${string}` | `#${string}` | ''}` | `/models/PersonaTrimmed&ListaDepartamentosDto&Color${`?${string}` | `#${string}` | ''}` | `/vms/PDGameVM${`?${string}` | `#${string}` | ''}` | { pathname: Router.RelativePathString, params?: Router.UnknownInputParams } | { pathname: Router.ExternalPathString, params?: Router.UnknownInputParams } | { pathname: `/`; params?: Router.UnknownInputParams; } | { pathname: `/_sitemap`; params?: Router.UnknownInputParams; } | { pathname: `/mappers/PersonaTrimmed&ListaDepartamentosDtoToPersonaTrimmed&ListaDepartamentosDto&ColorMapper`; params?: Router.UnknownInputParams; } | { pathname: `/models/PersonaTrimmed&ListaDepartamentosDto&Color`; params?: Router.UnknownInputParams; } | { pathname: `/vms/PDGameVM`; params?: Router.UnknownInputParams; };
    }
  }
}
