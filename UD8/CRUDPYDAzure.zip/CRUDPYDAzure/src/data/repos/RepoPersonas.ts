import { Persona } from "@/src/domain/entities/Persona";
import { IRepoPersonas } from "@/src/domain/interfaces/IRepoPersonas";
import APIConnection from "../api/APIConnection";

export default class RepoPersonas implements IRepoPersonas{
    private _apiBase: string

    constructor(apiBase: string){
        this._apiBase = APIConnection.getAPIBase() + "PersonasApi"
    }
    
    getPersonas(): Promise<Persona[]> {
        throw new Error("Method not implemented.");
    }
    getPersonaById(id: number): Promise<Persona> {
        throw new Error("Method not implemented.");
    }
    createOrEditPersona(p: Persona): Promise<number> {
        throw new Error("Method not implemented.");
    }
    deletePersona(id: number): Promise<number> {
        throw new Error("Method not implemented.");
    }
    
}