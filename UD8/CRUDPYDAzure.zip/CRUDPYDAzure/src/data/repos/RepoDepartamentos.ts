import { Departamento } from "@/src/domain/entities/Departamento";
import { IRepoDepartamentos } from "@/src/domain/interfaces/IRepoDepartamento";
import APIConnection from "../api/APIConnection";

export default class RepoDepartamentos implements IRepoDepartamentos{
    private _apiBase: string
    
        constructor(apiBase: string){
            this._apiBase = APIConnection.getAPIBase() + "DepartamentoApi"
        }
    
    
    getDepartamentos(): Promise<Departamento[]> {
        throw new Error("Method not implemented.");
    }
    getDepartamentoById(id: number): Promise<Departamento> {
        throw new Error("Method not implemented.");
    }
    createOrEditDepartamento(d: Departamento): Promise<number> {
        throw new Error("Method not implemented.");
    }
    deleteDepartamento(id: number): Promise<number> {
        throw new Error("Method not implemented.");
    }

}