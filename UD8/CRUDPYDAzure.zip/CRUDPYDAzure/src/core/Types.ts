const TYPES = {
    IRepoPersonas : Symbol.for("IRepoPersonas"),
    IRepoDepartamentos : Symbol.for("IRepoDepartamentos"),
    IPersonasUseCase : Symbol.for("IPersonasUseCase"),
    IDepartamentosUseCase : Symbol.for("IDepartamentosUseCase")
}

export { TYPES }

